#Print out the value of key b
d = {"a": 1, "b": 2}
print(d["b"])
