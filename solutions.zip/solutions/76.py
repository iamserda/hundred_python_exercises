# Please print the script in the expected output

from datetime import datetime

print(datetime.now().strftime("Today is %A, %B %d, %Y"))
