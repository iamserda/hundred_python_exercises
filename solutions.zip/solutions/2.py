a = 1
_a = 2
_a2 = 3
# 2a = 4 # error: variable names cannot start with a number.
_2a = 4

