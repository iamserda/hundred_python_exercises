#This script is supposed to print out the square root of 9, but there's an error.
#A: THe math module had not been imported yet
math.sqrt(9)
