#Add a c key with a value of 3 to the dictionary and print out the updated dictinary
d = {"a": 1, "b": 2}
d["c"] = 3
print(d)
