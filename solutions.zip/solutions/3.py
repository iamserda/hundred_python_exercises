a = 1
b = 2
print(a == b) # False
# print(b == c) # NameError, c is undefined because it was never declared nor initialized with a value.
c = 33
print(b == c) # False

