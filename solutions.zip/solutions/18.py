d = {"Name": "John", "Surname": "Smith"}
print(d["Smith"])
