#Count files with a .py extension inside the root1 directory]
import glob
file_list=glob.glob1("files","*.py")
print(len(file_list))
