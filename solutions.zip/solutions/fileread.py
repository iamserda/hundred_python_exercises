file = open("lines.txt","r")
a = file.read()
print(a)
