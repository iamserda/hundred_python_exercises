#Complete the script so that it prints out a list containing letters a, c, e, g, and i so the at a step of two
letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]
print(letters[::2]) # ["a", "c", "e", "g", "i"]
