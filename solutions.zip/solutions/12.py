#Create a script that generates a list whose items are products of the original list items multiplied by 10
my_range = range(1, 21)
print([10 * x for x in my_range]) #[10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200]
