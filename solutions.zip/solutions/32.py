#What will the script output
#A: It will output the last value of c which is 3
c = 1
def foo():
    return c
c = 3
print(foo())
